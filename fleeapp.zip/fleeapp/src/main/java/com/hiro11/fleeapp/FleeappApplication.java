package com.hiro11.fleeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FleeappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FleeappApplication.class, args);
	}

}
